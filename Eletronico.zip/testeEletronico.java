package IncioPOO;

public class testeEletronico {

	public static void main(String[] args) {			
			Eletronico compra1 = new Eletronico("Notebook","Acer",2000.00);
			compra1.imprimirInfo();			
			
		}
	}



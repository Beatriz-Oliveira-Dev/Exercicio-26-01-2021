package IncioPOO;

import java.text.NumberFormat;

public class Eletronico {
	//atributos
		private String tipo, marca;
		private double valor, novoValor;
		
	//construtor	
		public Eletronico (String tipo_elet, String marca_elet, double valor_elet) {
			
			this.tipo = tipo_elet;
			this.marca = marca_elet;
			this.valor = valor_elet;
		}
	// m�todos
		public String formatarPreco(){
			NumberFormat nf = NumberFormat.getCurrencyInstance();
			nf.setMinimumFractionDigits(2);
			String formatoValor = nf.format(valor);
			return formatoValor;
		}
		
		public double aplicarDesconto() {
			novoValor = valor-(valor*0.3);
			return novoValor;
		}
		public void imprimirInfo () {
			System.out.println("Tipo do eletr�nico: "+tipo+"\nMarca: "+marca+"\nValor original: "+this.formatarPreco()+"\nValor com desconto: "+this.aplicarDesconto()+"0");
		}
		public String getTipo() {
			return tipo;
		}
		public void setTipo(String tipo) {
			this.tipo = tipo;
		}
		public String getMarca() {
			return marca;
		}
		public void setMarca() {
			}
}

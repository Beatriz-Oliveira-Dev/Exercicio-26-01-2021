package IncioPOO;

import java.text.NumberFormat;

public class Cliente {
	private String nome;
	private String endereco;
	private int renda;
	private String cpf;
	private int cartao;
	
	public Cliente (String nome, String endereco, int renda, String cpf) {
		this.nome=nome;
		this.endereco=endereco;
		this.renda=renda;
		this.cpf=cpf;
	}
	
	public String formatarRenda(){
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		nf.setMinimumFractionDigits(2);
		String formatoRenda = nf.format(renda);
		return formatoRenda;
	}
	public void fichaCliente() {
		System.out.println("FICHA DO CLIENTE!!\nNome: "+nome+"\nEndere�o: "
	+endereco+"\nRenda: "+this.formatarRenda()+"\nCPF: "+cpf);
	}
	
	public String formatarCartao()
	{
		cartao=(int) (renda*0.3);
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		nf.setMinimumFractionDigits(2);
		String formatoCartao = nf.format(cartao);
		return formatoCartao;
	}
	public void seuLimite() {
		System.out.println("\nSeu limite de cart�o incialmente � :"+this.formatarCartao());
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public int getRenda() {
		return renda;
	}

	public void setRenda(int renda) {
		this.renda = renda;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public int getCartao() {
		return cartao;
	}

	public void setCartao(int cartao) {
		this.cartao = cartao;
	}
}

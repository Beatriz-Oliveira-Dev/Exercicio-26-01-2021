package IncioPOO;

public class testeCliente {

	public static void main(String[] args) {
		Cliente cliente1 = new Cliente("Beatriz Oliveira","Rua: Martins Osvaldo, 476",4000, "234.432.546-32"); 
		cliente1.fichaCliente();
		System.out.println("*****************************************************");
		cliente1.seuLimite();
		
		
	}
	
}


package Exers;

import java.util.Scanner;

public class parImpar {

	public static void main(String[] args) {
		int numero,par, impar;
		try (Scanner ler = new Scanner(System.in)) {
			System.out.println("Digite um numero inteiro: ");
			numero=ler.nextInt();
		}
		
		if(numero%2==0) {
			par=(int) Math.sqrt(numero);
			System.out.println("\nSeu numero � par, a raiz quadrado foi de "+par);
		}
		else {
			impar=(int) Math.pow(numero, 2);
			System.out.println("\nSeu numero � impar, ele elevado a 2 � "+impar);
		}

	}

}

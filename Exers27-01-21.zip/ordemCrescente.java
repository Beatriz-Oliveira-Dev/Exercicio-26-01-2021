package Exers;

import java.util.Scanner;

public class ordemCrescente {
	public static void main(String[] args) {
		int a,b,c,primeiro=0, segundo=0, terceiro=0;
						
		try (Scanner ler = new Scanner(System.in)) {
			System.out.println("\nEscreva o valor de A: ");
			a=ler.nextInt();
			System.out.println("\nEscreva o valor de B: ");
			b=ler.nextInt();
			System.out.println("\nEscreva o valor de C: ");
			c=ler.nextInt();
			}
		
		//If do a
		if (a<b && a<c) {
			primeiro=a;
		}
		else if (a<b && a>c) {
			segundo=a;
		}
		else if (a>b && a<c) {
			segundo=a;
		}
		else {
			terceiro=a;
		}
		//Acabou If Else a
		
		//If do b
		if (b<a && b<c) {
			primeiro=b;
		}
		else if (b<a && b>c) {
			segundo=b;
		}
		else if (b>a && b<c) {
			segundo=b;
		}
		else {
			terceiro=b;
		}
		//Acabou If Else b
		
		//If do c
		if (c<a && c<b) {
			primeiro=c;
		}
		else if (c<a && c>b) {
			segundo=c;
		}
		else if (c>a && c<b) {
			segundo=c;
		}
		else {
			terceiro=c;
		}
		//Acabou If Else c
		
		System.out.println("\nOrdem crescente "+primeiro+" ,"+segundo+" e "+terceiro);
		
	}

}

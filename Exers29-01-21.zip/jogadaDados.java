package Exercs;

import java.util.Scanner;

//2. Um dado � lan�ado 10 vezes e o valor correspondente � anotado. Fa�a um programa
//que gere um vetor com os lan�amentos, escreva esse vetor. A seguir determine e
//imprima a m�dia aritm�tica dos lan�amentos, contabilize e apresente tamb�m
//quantas foram as ocorr�ncias da maior pontua��o.

public class jogadaDados 
{

	public static void main(String[] args) 
	{
		int i,jogada[]=new int[10],media,soma=0,vezes=0;
		Scanner ler= new Scanner(System.in);
		
		
		for(i=0;i<10;i++) 
		{
			System.out.println("\nQual o valor da "+(i+1)+"� jogada? ");
			jogada[i]=ler.nextInt();
			soma=soma+jogada[i];
			
			if(jogada[i]==6) {
				vezes++;
			}
		}
		
		media=soma/10;
		
		System.out.println("\nA media � "+media);
		System.out.println("\nVoc� atingiu a pontua��o maxima "+vezes+" vezes");
	}

}

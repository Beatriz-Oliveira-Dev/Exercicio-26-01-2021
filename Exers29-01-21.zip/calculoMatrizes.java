package Exercs;

import java.util.Scanner;

//3. Escreve um programa que l� duas matrizes N1 (4,6) e N2(4,6) e cria:
//a) Uma matriz M1 cujos elementos ser�o as somas dos elementos de mesma posi��o
//das matrizes N1 e N2;
//b) Uma matriz M2 cujos elementos ser�o as diferen�as dos elementos de mesma
//posi��o das matrizes N1 e N2.

public class calculoMatrizes {

	public static void main(String[] args) {
		Scanner ler= new Scanner(System.in);
		
		int i,j,mat[][]=new int[2][2],mat2[][]=new int[2][2];
		int matrizSoma[][]=new int[2][2];
	
		//matriz1
		System.out.println("\nPREENCHENDO A PRIMEIRA MATRIZ");
		for(i=0;i<2;i++) {
			
			for(j=0;j<2;j++) {
				System.out.println("\nAgora entre com o ["+(i+1)+"] e ["+(j+1)+"]");
				mat[i][j]=ler.nextInt();
			}
		}
		//matriz2
		System.out.println("\nPREENCHENDO A SEGUNDA MATRIZ");
		for(i=0;i<2;i++) {
			
			for(j=0;j<2;j++) {
				System.out.println("\nAgora entre com o ["+(i+1)+"] e ["+(j+1)+"]");
				mat2[i][j]=ler.nextInt();
			}
		}

		//mostrando matriz1
		System.out.println("\nMONTRANDO A PRIMEIRA MATRIZ");
		for(i=0;i<2;i++)
		{
			System.out.printf("\n %d� linha: ",(i+1));
			for(j=0;j<2;j++)
			{
				System.out.printf(" %d ",mat[i][j]);
				
			}
			System.out.printf("\n");
		}
		
		//mostrando matriz2
		System.out.println("\nMONTRANDO A SEGUNDA MATRIZ");
		for(i=0;i<2;i++)
		{
			System.out.printf("\n %d� linha: ",(i+1));
			for(j=0;j<2;j++)
			{
				System.out.printf(" %d ",mat2[i][j]);
				
			}
			System.out.printf("\n");
		}
		
		//matrizSoma
		System.out.println("\nSOMA DAS MATRIZES");
		for(i=0;i<2;i++)
		{
			System.out.printf(" %d� linha: ",(i+1));
			for(j=0;j<2;j++)
			{
				matrizSoma[i][j]=mat[i][j]+mat2[i][j];
				System.out.printf(" %d ",matrizSoma[i][j]);
				
			}
			System.out.printf("\n");
		}
		
		//diferen�aDasMatrizes
		System.out.println("\nDIFEREN�A DAS MATRIZES");
		for(i=0;i<2;i++)
		{
			System.out.printf(" %d� linha: ",(i+1));
			for(j=0;j<2;j++)
			{
				matrizSoma[i][j]=mat[i][j]-mat2[i][j];
				System.out.printf(" %d ",matrizSoma[i][j]);
				
			}
			System.out.printf("\n");
		}
	}

}

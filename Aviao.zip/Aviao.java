package IncioPOO;

import java.text.NumberFormat;

public class Aviao {
	private String modelo;
	private int lugares;
	private String tipo;
	private int preco;
	
	public Aviao (String modelo, int lugares, String tipo, int preco) {
		this.modelo=modelo;
		this.lugares=lugares;
		this.tipo=tipo;
		this.preco=preco;
		
	}
	public String formatarPreco(){
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		nf.setMinimumFractionDigits(2);
		String formatoPreco = nf.format(preco);
		return formatoPreco;
	}
	
	public void fichaAviao() {
		System.out.println("FICHA DO AVI�O!!\nModelo: "+modelo+"\nLugares: "
	+lugares+"\nTipo: "+tipo+"\nPre�o do aluguel: "+this.formatarPreco());
		
	}
}


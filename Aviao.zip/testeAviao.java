package IncioPOO;

public class testeAviao {

	public static void main(String[] args) {
		Aviao[] aluguelAviao = new Aviao[3];
		
		aluguelAviao[0] = new Aviao("Esquilo AS 350B3",6, "HELI MONOTURBINA",2000);
		aluguelAviao[1] = new Aviao("Eurocopter EC 130B4",7, "HELI MONOTURBINA",6000);
		aluguelAviao[2] = new Aviao("Phenom 100E",8, "JATO",10000);
		
		System.out.println("BEM VINDO A TABELA DE ALUGUEL");
		System.out.println("");
		for(Aviao listaAviao:aluguelAviao) {
			listaAviao.fichaAviao();
			System.out.println("*******************************************");
		}
		


	}

}

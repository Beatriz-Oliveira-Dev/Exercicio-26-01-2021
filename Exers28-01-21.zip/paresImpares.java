package Exercs;

import java.util.Scanner;

public class paresImpares 
{
	public static void main(String[] args) 
	{
		int numero, par=0, impar=0, contador;
		try (Scanner ler = new Scanner(System.in)) {
			for(contador=1;contador<=10;contador++) 
			{
				System.out.println("\nDigite o numero "+contador+": ");
				numero=ler.nextInt();
				if(numero%2==0) 
				{
					par++;
				}
				else 
				{
					impar++;
				}			
			}
		}
		
		System.out.println("\nTemos "+par+" numeros pares e "+impar+" numeros impares");
	}

}

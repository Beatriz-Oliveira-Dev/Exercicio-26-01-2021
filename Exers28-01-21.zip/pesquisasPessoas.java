package Exercs;

import java.util.Scanner;

public class pesquisasPessoas {

	public static void main(String[] args) 
	{
		int idade, sexo, humor,pessoe=0,calmes=0,mulheresNervosas=0; 
		int homensAgressivos=0,outrosCalmes=0,nervososMaiores40=0,calmesMenores18=0;
		try (Scanner ler = new Scanner(System.in)) {
			while(pessoe<150) 
			{
				System.out.println("\nQual a sua idade?: ");
				idade=ler.nextInt();
				
				System.out.println("\nQual seu sexo? (Digite o numero)\n1-FEMININO\n2-MASCULINO\n3-OUTROS\nResposta: ");
				sexo=ler.nextInt();
				
				System.out.println("\nVoc� � uma pessoa...\n1-calme\n2-nervose\n3-agressive\nResposta: ");
				humor=ler.nextInt();
				
				if(humor==1) 
				{
					calmes++;
				}
				if(sexo==1 && humor==2) 
				{
					mulheresNervosas++;
				}
				if(sexo==2 && humor==3) 
				{
					homensAgressivos++;
				}
				if(sexo==3 && humor==1) 
				{
					outrosCalmes++;
				}
				if(humor==2 && idade>40) 
				{
					nervososMaiores40++;
				}
				if(humor==1 && idade<18) 
				{
					calmesMenores18++;
				}
				pessoe++;
			}
		}
		
		System.out.println("\nResultado da pesquisa!!\nPessoas Calmas: "+calmes+"\nMulheres Nervosas: "+mulheresNervosas+"\nHomens Agressivos: "+homensAgressivos);
		System.out.println("\nOutros Calmes: "+outrosCalmes+"\nNervosos Maiores de 40: "+nervososMaiores40+"\nCalmes Menores de 18: "+calmesMenores18);

	}

}

package Exercs;

import java.util.Scanner;

public class somaNumero {

	public static void main(String[] args) 
	{
		int numero, somaNumero=0;
		try (Scanner ler = new Scanner(System.in)) {
			System.out.println("\nDigite '0'(zero) para parar!! ");
			
			do {
				System.out.println("\nDigite um numero inteiro: ");	
				numero=ler.nextInt();
				somaNumero=somaNumero+numero;
				}while(numero!=0);
		}
		
		System.out.println("\nA soma foi "+somaNumero);
				
	}

}
